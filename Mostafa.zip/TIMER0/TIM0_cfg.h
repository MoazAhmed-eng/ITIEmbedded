

#ifdef TIM0_H
#define TIM0_MODE        		TIM0_NORMAL_MODE
#define TIM0_PRESCALLER  		TIM0_PRESCALLER_8
#define TIM0_TICK_TIME		 	(TIM0_PRESCALLER/8)
#define TIM0_RESOLUTION			((uint8) 0x08)



#endif
