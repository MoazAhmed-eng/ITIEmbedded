

#ifndef EXTINT0_H
#define EXTINT0_H


void EXTINT0_voidInit(void);


void EXTINT0_voidEnable(void);


void EXTINT0_voidDisable(void);

void EXTINT0_voidSetCallBack(pf pfCallbackCpy);

void EXTINT0_voidSetSenseValue(uint8 u8SenseValueCpy);

#endif
