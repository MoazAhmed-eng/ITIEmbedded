
#ifndef EXTINT0_CFG_H
#define EXTINT0_CFG_H

/*
LOW_LEVEL
IOC(Interrupt On Change)
FALLING_EDGE
RISING_EDGE
*/

#define EXTINT0_SENSE_MODE	LOW_LEVEL


#endif