
#ifndef EXTINT1_CFG_H
#define EXTINT1_CFG_H

/*
LOW_LEVEL
IOC(Interrupt On Change)
FALLING EDGE
RISING EDGE
*/

#define EXTINT1_SENSE_MODE	LOW_LEVEL


#endif