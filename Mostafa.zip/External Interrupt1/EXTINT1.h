

#ifndef EXTINT1_H
#define EXTINT1_H


void EXTINT1_voidInit(void);


void EXTINT1_voidEnable(void);


void EXTINT1_voidDisable(void);

void EXTINT1_voidSetCallBack(pf pfCallbackCpy);

void EXTINT1_voidSetSenseValue(uint8 u8SenseValueCpy);
#endif
