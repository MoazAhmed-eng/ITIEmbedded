

#ifndef EXTINT2_H
#define EXTINT2_H


void EXTINT2_voidInit(void);


void EXTINT2_voidEnable(void);


void EXTINT2_voidDisable(void);

void EXTINT2_voidSetCallBack(pf pfCallbackCpy);

#endif
